ALTER TABLE `#__helloworld` ADD `catid` int(11) NOT NULL DEFAULT '0';

